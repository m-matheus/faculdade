#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
main()

{
   setlocale(LC_ALL, "Portuguese");
   // codigo
   printf ("Hello, Word\n");
   printf("Hunder E. Corr�a Junior\n");
   system("PAUSE");
}

